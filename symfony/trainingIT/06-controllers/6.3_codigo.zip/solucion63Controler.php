<?php

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use App\Domain\Model\ProductRepository;

class Solucion63Controller extends Controller
{

    public function getProductosJSON(Request $request, ProductRepository $productRepository)
    {
        return $this->json($productRepository->findAll());
    }
}
