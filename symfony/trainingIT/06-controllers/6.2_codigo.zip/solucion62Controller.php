<?php

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class Solucion62Controller extends Controller
{

    public function downloadPDF(Request $request)
    {
        return $this->file('/path/al/fichero.pdf');
    }
}
