<?php

namespace App\Controller;

use App\Entity\Alumno;
use App\Entity\Asignatura;
use App\Repository\AlumnoRepository;
use App\Repository\AsignaturaRepository;
use App\Repository\NotaRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class StudentsController extends AbstractController
{
    /**
     * @Route("/", name="students",methods={"GET"})
     */
    public function index(AlumnoRepository $alumnoRepository)
    {
        $students = $alumnoRepository->findAll();

        return $this->render('students/index.html.twig', [
            'students' => $students
        ]);
    }

    /**
     * @Route("/students_notes/{id}", name="students_notes",methods={"GET"})
     */
    public function studentNotes(Alumno $student, NotaRepository $notaRepository)
    {

        $notes = [];
        $averageGrade = 0;
        $countSignature = 0;

        foreach ($student->getAsignatura() as $asignatura) {

            /* Supongo que por convocatoria solo voy tener una nota final por cada asignatura */
            $nota = $notaRepository->findOneBy(['asignatura' => $asignatura], ['nConvocatoria' => 'DESC']);
            $notes[] = $nota;

            if (!is_null($nota)) {
                $averageGrade += $nota->getNota();
                $countSignature++;
            }
        }

        $averageGrade = $averageGrade / $countSignature;

        return $this->render('students/notes.html.twig', [
            'student' => $student,
            'notes' => $notes,
            'averageGrade' => $averageGrade
        ]);
    }

    /**
     * @Route("/students_signature/{id}", name="students_signature", methods={"GET"})
     */
    public function studentsSignatures(Alumno $student, AsignaturaRepository $asignaturaRepository)
    {

        /* Asignaturas del grado que cursa el alumno */
        $signatures = $asignaturaRepository->findBy(['grado' => $student->getGrado()]);

        return $this->render('students/signatures.html.twig', [
            'student' => $student,
            'signatures' => $signatures
        ]);
    }

    /**
     * @Route("/signature_add/{id}/{idsignature}", name="signature_add", methods={"GET"})
     */
    public function addSignature(Alumno $student, $idsignature)
    {

        $signature = $this->getDoctrine()->getRepository(Asignatura::class)->find($idsignature);

        if (!$signature) {
            throw $this->createNotFoundException('El producto solicitado no existe');
        }

        $student->addAsignatura($signature);

        $em = $this->getDoctrine()->getManager();
        $em->persist($student);
        $em->flush();

        $this->addFlash(
            'notice',
            "'Matriculado con éxito en {$signature->getNombre()} "
        );

        return  $this->redirectToRoute('students_signature', [
            'id' => $student->getId(),
        ]);
    }

    /**
     * @Route("/signature_remove/{id}/{idsignature}", name="signature_remove", methods={"GET"})
     */
    public function removeSignature(Alumno $student, $idsignature)
    {

        $signature = $this->getDoctrine()->getRepository(Asignatura::class)->find($idsignature);

        if (!$signature) {
            throw $this->createNotFoundException('El producto solicitado no existe');
        }

        $student->removeAsignatura($signature);

        $em = $this->getDoctrine()->getManager();
        $em->persist($student);
        $em->flush();

        $this->addFlash(
            'notice',
            "Desmatriculado con éxito en {$signature->getNombre()} "
        );

        return $this->redirectToRoute('students_signature', [
            'id' => $student->getId(),
        ]);
    }
}
