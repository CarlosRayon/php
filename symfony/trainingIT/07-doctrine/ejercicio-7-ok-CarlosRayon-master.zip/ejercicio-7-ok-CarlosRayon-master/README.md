# Ejercicio 07

## Enunciado:

Dada la estructura de base de datos de alumnos.zip, programar una mini-aplicación con las siguientes funcionalidades:

-   Página con listado de alumnos con un enlace para ver las notas de un alumno concreto y otro enlace para ver las asignaturas en las que está matriculado.

-   Al pinchar en el enlace para ver las notas de un alumno, se mostrará una página con el listado de las notas del alumno/a seleccionado/a. Mostrará solamente la última nota de cada asignatura. Marcará las asignaturas aprobadas (última nota >= 5) y también mostrará la nota media del alumno (para la media solamente cuenta la última nota en cada asignatura.)

-   Al pinchar en el enlace para ver las asignaturas de un alumno, página con el listado de asignaturas, con posibilidad de desmatricular al alumno de una asignatura y/o matricularle de otras asignaturas.

## Entrega:

Subir el enlace al repositorio cuando el ejercicio esté terminado

## Desarrollo

-   Clonar repositorio
-   Instalar todo lo necesario con `composer install` (El proyecto necesita php version 7.4)
-   Crear a "mano" la base datos en local e importar el la base de datos mediante el fichero _alumnoscondatos.sql_
-   Configurar la conexión a la base datos en el fichero _.env_
-   Arrancamos servidor local de symfony `symfony serve` (en mi caso tengo instalado el CLI de symfony)
-   Creamos las entidades `bin/console doctrine:mapping:import App\\Entity annotation --path=src/Entity`
-   Añadimos en cada entidad la linea en las entidades que permitirá al siguiente comando crear también los repositorios de cada entidad `@ORM\Entity(repositoryClass="App\Repository\<nameRepository>")`
-   Regeneramos entidades para crear los settter getter `bin/console make:entity --regenerate App`
-   Creamos un controlador `bin/console make:controller StudentsController`
-   Creamos las plantillas de twig y las lógicas en el controlador _StudenController_

## Notas

He incluido el [Starter template](https://getbootstrap.com/docs/4.0/getting-started/introduction/#starter-template) de bootstrap en el fichero base.html.twig para poder dar un poco estilo al ejercicio.
