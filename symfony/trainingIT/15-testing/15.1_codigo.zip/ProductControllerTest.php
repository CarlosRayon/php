<?php

namespace App\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ProductControllerTest extends WebTestCase
{
    public function testProductList()
    {
        $client = static::createClient();
        $crawler = $client->request('GET', '/producto');
        $this->assertLessThanOrEqual(10, $crawler->filter('table.table > tbody > tr')->count());
    }
}
