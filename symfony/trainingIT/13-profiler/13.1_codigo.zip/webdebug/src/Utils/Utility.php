<?php

namespace App\Utils;
/**
 * Clase que contiene la lógica de negocio de métodos personalizados para diferente índole
 */
class Utility
{
    /**
     * Calcula la edad a partir de la fecha de nacimiento
     *
     * @param Date $birthDate
     * @return int|null
     */
    public function getAge($birthDate)
    {   
        if($birthDate != null){
            $today = new \DateTime();
            $interval = $today->diff($birthDate);
            return $interval->y;
        }
        return null;
    } 

    /**
     * Obtiene las iniciales de las palabras de un string pasado por parámetro
     *
     * @param string $words
     * @return string|null
     */
    public function getInitialsWords($words){
        if(trim($words) != null){
            $words = explode(" ", $words);
            $initials = '';
            foreach ($words as $w) {
                $initials .= $w[0];
            }
            return $initials;
        }
        return null;   
    }
}