<?php

namespace App\DataCollector;

use Symfony\Component\HttpKernel\DataCollector\DataCollector;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

use App\Utils\Utility;
use App\Entity\Usuario;

/**
 * Data Collector que muestra en la barra de depuración las iniciales y la edad del usuario autenticado
 */
class RequestCollector extends DataCollector
{
    /**
     * Obtención de la información del usuario autenticado
     *
     * @var Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface
     */
    private $tokenStorage; 

    /**
     * Clase que contiene la lógica de negocio de métodos personalizados para diferente índole. En este caso, usa el método getAge 
     * para calcular la edad a partir de una fecha de nacimiento y getInitialsWords que obtiene las iniciales del nombre completo
     *
     * @var App\Utils\Utility
     */
    private $utility;   

    public function __construct(TokenStorageInterface $tokenStorage, Utility $utility)
    {
        $this->tokenStorage   = $tokenStorage;
        $this->utility = $utility;
    }    

    /**
     * Obtiene la edad del usuario y las iniciales del usuario autenticado
     *
     * @param Request $request
     * @param Response $response
     * @param \Exception $exception
     * @return array
     */
    public function collect(Request $request, Response $response, \Exception $exception = null)
    {
        //años de usuario
        $age = 0;
        //iniciales del nombre completo del usuario
        $initials = '';
        //indica si está autenticado o no
        $authenticatedUser = false;

        if ($this->tokenStorage->getToken() != null){
            $user = $this->tokenStorage->getToken()->getUser();
            //Si está autenticado y es objeto Usuario calculamos los años y obtenemos las iniciales
            if ($user instanceof Usuario){
                $age = $this->utility->getAge($user->getBirthDate());
                $fullName = $user->getFirstName().' '.$user->getSurnames();
                $initials = $this->utility->getInitialsWords($fullName);
                $authenticatedUser = true;
            }
        }

        $this->data = array(
            'age' => $age,
            'initials' => $initials,
            'authenticatedUser' => $authenticatedUser,
        ); 
    }

    public function reset()
    {
        $this->data = array();
    }

    public function getName()
    {
        return 'app.request_collector';
    }

    public function getAge()
    {
        return $this->data['age'];
    }

    public function getInitials()
    {
        return $this->data['initials'];
    }

    public function getAuthenticatedUser()
    {
        return $this->data['authenticatedUser'];
    }
}