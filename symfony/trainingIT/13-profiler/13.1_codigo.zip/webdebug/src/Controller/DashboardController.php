<?php

namespace App\Controller;

use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use App\Utils\Utility;

class DashboardController extends Controller
{

    /**
     * Muestra la información del usuario autenticado y calcula su edad a partir de la fecha de nacimiento.
     *
     * @param Utility $utility Clase que contiene la lógica de negocio de métodos personalizados para diferente índole. 
     *                         En este caso, usa el método getAge para calcular la edad a partir de una fecha de nacimiento. 
     * @return Symfony\Component\HttpFoundation\Response
     * 
     * @Route("/dashboard", name="dashboard")
     */
    public function index (Utility $utility)
    {
        $user = $this->getUser();

        return $this->render('dashboard/index.html.twig', [
            'age' => $utility->getAge($user->getBirthDate()),
            'user' => $user
        ]);
    }  
}
