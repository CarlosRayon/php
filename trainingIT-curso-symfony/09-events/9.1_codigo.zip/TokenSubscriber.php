<?php
// src/EventSubscriber/TokenSubscriber.php
namespace App\EventSubscriber;

use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;

use App\Services\TokenValidatorService;

class TokenSubscriber implements EventSubscriberInterface
{
    private $tokenValidatorService;

    public function __construct(TokenValidatorService $tokenValidatorService)
    {
        $this->tokenValidatorService = $tokenValidatorService;
    }

    // Valdría también por ejemplo, kernel.controller
    public static function getSubscribedEvents()
    {
        return [
           'kernel.request' => 'onKernelRequest',
        ];
    }

    public function onKernelRequest(GetResponseEvent $event)
    {
        //Obtenemos el token de la petición
        $token = $event->getRequest()->query->get('token');

        //Usamos el servicio que nos indica si el token es válido o no para lanzar un AccessDeniedHttpException
        //en caso que no sea correcto
        if (!$this->tokenValidatorService->validate($token))
            throw new AccessDeniedHttpException('Token inválido.');
    }
}