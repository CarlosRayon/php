<?php

namespace App\Repository;

use App\Entity\Grado;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

class GradoRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Grado::class);
    }

    /**
     * Devuelve la nota media de las asignaturas de un grado entre dos fechas dadas
     *
     * @param $nombreGrado
     * @param $nombreGrado
     * @param $nombreGrado
     * @return array
     */
    public function getNotaMediaGrado($nombreGrado, $fechaInicio, $fechaFin)
	{
        return $this->createQueryBuilder('g')
                ->select('a.nombre','avg(n.nota) as nota_media')
                ->join('g.asignaturas','a')
                ->join('a.notas','n')
                ->where('g.nombre = :nombreGrado')
                ->andWhere('n.fecha BETWEEN :fechaInicio AND :fechaFin')
                ->groupBy('n.asignatura')
                ->setParameter('nombreGrado', $nombreGrado)
                ->setParameter('fechaInicio', $fechaInicio)
                ->setParameter('fechaFin', $fechaFin)
                ->getQuery()
                ->execute();
   }
}