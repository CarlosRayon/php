<?php

namespace App\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

use Symfony\Component\Console\Helper\Table;
use Symfony\Component\Console\Helper\TableCell;

use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Grado;

class InformesNotasCommand extends Command
{
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        parent::__construct();
        $this->entityManager = $entityManager;
    }

    protected function configure()
    {
        $this
            ->setName('informes:notas')
            ->setDescription('Listado de las notas medias de las asignaturas de un grado entre dos fechas dadas ')
            ->addArgument('nombregrado', InputArgument::REQUIRED, 'Nombre del grado')
            ->addArgument('fechaInicio', InputArgument::REQUIRED, 'Fecha inicio (yyyy-mm-dd)')
            ->addArgument('fechaFin', InputArgument::REQUIRED, 'Fecha fin (yyyy-mm-dd)')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $nombreGrado = $input->getArgument('nombreGrado');
        $fechaInicio = $input->getArgument('fechaInicio');
        $fechaFin = $input->getArgument('fechaFin');

        $asignaturas = $this->entityManager
            ->getRepository(Grado::class)
            ->getNotaMediaGrado($nombreGrado, $fechaInicio, $fechaFin);

        $rows = [];
        foreach ($asignaturas as $asignatura){
            $rows[] = [$asignatura['nombre'], $asignatura['nota_media']]; 
        }   

        $table = new Table($output);

        if (!empty($rows)){
            $table->setHeaders([
                [new TableCell('Grado: '.$nombreGrado.' ---- Fecha: '.$fechaInicio.' / '.$fechaFin, ['colspan' => 2])],
                ['Asignatura', 'Nota Media'],
            ]);

            $table->setRows($rows);
        }else{
            $table->setHeaders(array('No se encontraron registros'));
        }

        $table->render();
    }
}