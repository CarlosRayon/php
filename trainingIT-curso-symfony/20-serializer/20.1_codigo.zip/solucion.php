<?php

$encoder = new JsonEncoder();
$normalizer = new ObjectNormalizer();

$normalizer->setCircularReferenceHandler(function ($object) {
    return $object->__toString();
});

$serializer = new Serializer(array($normalizer), array($encoder));
