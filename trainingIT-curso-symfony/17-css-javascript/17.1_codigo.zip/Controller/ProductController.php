<?php

namespace App\Controller;

use App\Entity\Product;
use App\Form\ProductType;
use App\Repository\ProductRepository;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Translation\TranslatorInterface;

/**
 * @Route("/{_locale}/product", defaults={"_locale": "en"}, requirements={"_locale": "en|es"})
 */
class ProductController extends Controller
{
    /**
     * @Route("/index2", name="product_index2", methods="GET")
     * @param ProductRepository $productRepository
     * @param TranslatorInterface $translator
     * @return Response
     */
    public function index2(ProductRepository $productRepository, TranslatorInterface $translator): Response
    {
        $products = $productRepository->findAll();
        return $this->render(
            'product/index2.html.twig',
            [
                'products' => $products
            ]
        );
    }

}
