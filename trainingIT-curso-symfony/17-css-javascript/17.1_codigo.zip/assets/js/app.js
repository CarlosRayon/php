$(document).ready(function() {
   $('table > tbody > tr').click(function () {
       $('#detalle_id').html($(this).data('id'));
       $('#detalle_name').html($(this).data('name'));
       $('#detalle_price').html($(this).data('price'));
   });
});